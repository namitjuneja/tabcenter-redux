import TabCenter from "./tabcenter.js";

// Start-it up!
const tabCenter = new TabCenter();
tabCenter.init();

// For testing!
window.tabCenter = tabCenter;
